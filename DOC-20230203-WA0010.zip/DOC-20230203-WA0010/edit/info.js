const infotext = `‍Hy Saya Ndraa Bot
Ini Adalah Informasi Saya
⚛️ Version : 4
🤖 Bot Name : NdraXD
👨‍💻 Owner : NdraXd`
exports.infotext = infotext