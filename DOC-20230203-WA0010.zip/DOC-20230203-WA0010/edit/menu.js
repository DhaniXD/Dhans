const menutext = `
𝗠𝗔𝗜𝗡 𝗠𝗘𝗡𝗨
📄• rules
⏱️• runtime
📈• stats
🎀• listvip
🚫• chanceban

𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨
NOTE : KHUSUS GROUP
🛠• kick
🛠• open
🛠• close
🛠• revoke
🛠• linkgc
🛠• tag

𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨
 NOTE : KHUSUS OWNER
👨‍💻• add number/tag @
👨‍💻• del number/tag @

𝗕𝗨𝗚 𝗖𝗛𝗔𝗧
NOTE : akses dalam group
😈• bugpc 62xxx
😈• bugchat 62xxx
😈• santet 62xxx

𝗕𝗨𝗚 𝗚𝗥𝗢𝗨𝗣
NOTE : KHUSUS AKSES VIP
😈• buggc Linkgc
😈• santetgc Linkgc
😈• otwgc Linkgc

𝗕𝗨𝗚 𝗩𝗘𝗥𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡
NOTE : KHUSUS AKSES VIP
😈• verif 62xxx
😈• kenon 62xxx
😈• ban 62xxx

𝗕𝗨𝗚 𝗘𝗫𝗧𝗥𝗔
NOTE : KHUSUS BOT
😈• turu
😈• virus
😈• off

@ NdraXD
 `
exports.menutext = menutext